# SmartDine AI Pro CV

This upgraded version includes a real computer vision pipeline.

## Features
- FastAPI backend
- React + Vite + Tailwind frontend
- Login / signup UI
- Admin dashboard
- Restaurant recommendation engine
- PostgreSQL-ready SQLAlchemy models
- Table booking system
- Map view
- Real computer vision pipeline using YOLO + OpenCV
- Detection of people, chairs, and dining tables
- Table occupancy analytics
- Motion-based dining activity score
- Waiting time estimation from CV output
- Docker support

## How the CV part works
1. Admin uploads a recorded restaurant video from the Admin page.
2. Backend processes frames with OpenCV.
3. YOLO detects people, chairs, and dining tables.
4. The system estimates crowd, occupied tables, free tables, activity level, and waiting time.
5. Users only see recommendation results. Video processing is handled in the backend/admin flow.

## Backend setup
```bash
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Frontend setup
```bash
cd frontend
npm install
npm run dev
```

If `npm run dev` does not work on your system, `npm start` is also added.

## Notes
- The first YOLO run may take time because model weights may download once.
- Add your own recorded videos later for dataset testing.
- Normal users do not upload video. Admin/testing flow handles CV analysis.


## Demo flow for CV-based recommendations

1. Start backend and frontend.
2. Open the Admin page.
3. Select a restaurant from the dropdown.
4. Upload that restaurant's CCTV or recorded video.
5. Wait for CV analysis to finish.
6. Go back to the Home page and search that city.
7. The selected restaurant will now show CV-based crowd and waiting time instead of default dataset values.
