import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";

export default function MapView({ items }) {
  const center = items?.length ? [items[0].latitude, items[0].longitude] : [20.5937, 78.9629];

  return (
    <div className="rounded-3xl overflow-hidden border border-white/10">
      <MapContainer center={center} zoom={12} scrollWheelZoom={true} style={{ height: "380px", width: "100%" }}>
        <TileLayer
          attribution='&copy; OpenStreetMap contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {items.map((item) => (
          <Marker key={item.id} position={[item.latitude, item.longitude]}>
            <Popup>
              <b>{item.name}</b><br />
              Wait: {item.waiting_time} min<br />
              Distance: {item.distance_km} km
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}
