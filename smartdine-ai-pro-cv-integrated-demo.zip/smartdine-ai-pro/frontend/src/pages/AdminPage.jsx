import { useEffect, useState } from "react";
import { api } from "../lib/api";

export default function AdminPage() {
  const [stats, setStats] = useState(null);
  const [bookings, setBookings] = useState([]);
  const [cv, setCv] = useState(null);
  const [cvMsg, setCvMsg] = useState("No analysis yet.");
  const [restaurants, setRestaurants] = useState([]);
  const [restaurantId, setRestaurantId] = useState("");

  useEffect(() => {
    api.get("/admin/stats").then((res) => setStats(res.data));
    api.get("/bookings").then((res) => setBookings(res.data));
    api.get("/video/restaurants").then((res) => {
      setRestaurants(res.data);
      if (res.data.length) setRestaurantId(String(res.data[0].id));
    });
  }, []);

  const uploadVideo = async (e) => {
    const file = e.target.files?.[0];
    if (!file || !restaurantId) return;
    const fd = new FormData();
    fd.append("restaurant_id", restaurantId);
    fd.append("file", file);
    setCvMsg("Analyzing video and linking it to the selected restaurant. First run can take time because YOLO may download weights.");
    try {
      const res = await api.post("/video/upload", fd, { headers: { "Content-Type": "multipart/form-data" } });
      setCv(res.data);
      setCvMsg(res.data.message || "Analysis complete");
      api.get("/admin/stats").then((r) => setStats(r.data));
    } catch (e2) {
      setCv(null);
      setCvMsg(e2?.response?.data?.detail || "Video analysis failed");
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-10 text-white">
      <h1 className="text-4xl font-black">Admin Panel</h1>
      <p className="text-slate-400 mt-2">Manage system overview, bookings, and backend computer vision analysis</p>

      <div className="rounded-3xl bg-white/5 border border-white/10 p-6 mt-8">
        <h2 className="text-2xl font-bold">CCTV / Recorded Video Analysis</h2>
        <p className="text-slate-400 mt-2">Select a restaurant, upload its CCTV or recorded video, and the CV result will update that restaurant's crowd and waiting time in recommendations.</p>

        <div className="grid md:grid-cols-2 gap-4 mt-4">
          <select
            value={restaurantId}
            onChange={(e) => setRestaurantId(e.target.value)}
            className="rounded-2xl bg-black/20 p-3 border border-white/10"
          >
            {restaurants.map((r) => (
              <option key={r.id} value={r.id}>
                {r.name} - {r.city}
              </option>
            ))}
          </select>

          <input type="file" accept="video/*" onChange={uploadVideo} className="block w-full text-sm rounded-2xl bg-black/20 p-3 border border-white/10" />
        </div>

        <div className="mt-4 text-sm text-emerald-300">{cvMsg}</div>

        {cv && (
          <div className="grid md:grid-cols-3 gap-4 mt-5">
            <div className="rounded-2xl bg-black/20 p-4">Avg People: {cv.avg_people_count}</div>
            <div className="rounded-2xl bg-black/20 p-4">Occupied Tables: {cv.avg_occupied_tables}</div>
            <div className="rounded-2xl bg-black/20 p-4">Free Tables: {cv.avg_free_tables}</div>
            <div className="rounded-2xl bg-black/20 p-4">Activity: {cv.overall_dining_activity_label}</div>
            <div className="rounded-2xl bg-black/20 p-4">Wait Time: {cv.estimated_waiting_time_minutes} min</div>
            <div className="rounded-2xl bg-black/20 p-4">Restaurant ID Linked: {cv.restaurant_id}</div>
          </div>
        )}
      </div>

      <div className="rounded-3xl bg-white/5 border border-white/10 p-6 mt-8">
        <h2 className="text-2xl font-bold">System summary</h2>
        {stats ? (
          <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-4 mt-5">
            <div className="rounded-2xl bg-black/20 p-4">Restaurants: {stats.total_restaurants}</div>
            <div className="rounded-2xl bg-black/20 p-4">Bookings: {stats.total_bookings}</div>
            <div className="rounded-2xl bg-black/20 p-4">Avg wait: {stats.avg_waiting_time} min</div>
            <div className="rounded-2xl bg-black/20 p-4">Avg crowd: {stats.avg_crowd_count}</div>
          </div>
        ) : (
          <div className="mt-4">Loading...</div>
        )}
      </div>

      <div className="rounded-3xl bg-white/5 border border-white/10 p-6 mt-8 overflow-auto">
        <h2 className="text-2xl font-bold mb-4">Recent bookings</h2>
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="text-slate-400 border-b border-white/10">
              <th className="py-3">User</th>
              <th className="py-3">Email</th>
              <th className="py-3">Restaurant</th>
              <th className="py-3">Guests</th>
              <th className="py-3">Slot</th>
            </tr>
          </thead>
          <tbody>
            {bookings.map((b) => (
              <tr key={b.booking_id} className="border-b border-white/5">
                <td className="py-3">{b.user}</td>
                <td className="py-3">{b.email}</td>
                <td className="py-3">{b.restaurant}</td>
                <td className="py-3">{b.guests}</td>
                <td className="py-3">{b.slot}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
