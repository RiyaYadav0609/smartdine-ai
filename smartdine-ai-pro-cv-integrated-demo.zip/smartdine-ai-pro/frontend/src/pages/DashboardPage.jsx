import { useEffect, useState } from "react";
import { api } from "../lib/api";
import StatCard from "../components/StatCard";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

export default function DashboardPage() {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    api.get("/admin/stats").then((res) => setStats(res.data));
  }, []);

  if (!stats) return <div className="p-6 text-white">Loading dashboard...</div>;

  const cityData = Object.entries(stats.city_distribution).map(([city, count]) => ({ city, count }));

  return (
    <div className="max-w-7xl mx-auto px-6 py-10 text-white">
      <h1 className="text-4xl font-black">Live Dashboard</h1>
      <p className="text-slate-400 mt-2">Operational insights for crowd and booking trends</p>

      <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-5 mt-8">
        <StatCard title="Restaurants" value={stats.total_restaurants} subtitle="Tracked in system" />
        <StatCard title="Bookings" value={stats.total_bookings} subtitle="Confirmed reservations" />
        <StatCard title="Avg wait" value={`${stats.avg_waiting_time} min`} subtitle="Estimated from crowd data" />
        <StatCard title="Avg crowd" value={stats.avg_crowd_count} subtitle="People count estimate" />
      </div>

      <div className="grid lg:grid-cols-2 gap-6 mt-10">
        <div className="rounded-3xl bg-white/5 border border-white/10 p-5">
          <h2 className="text-xl font-bold mb-4">City distribution</h2>
          <div style={{ width: "100%", height: 320 }}>
            <ResponsiveContainer>
              <BarChart data={cityData}>
                <XAxis dataKey="city" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-3xl bg-white/5 border border-white/10 p-5">
          <h2 className="text-xl font-bold mb-4">Restaurant share</h2>
          <div style={{ width: "100%", height: 320 }}>
            <ResponsiveContainer>
              <PieChart>
                <Pie data={cityData} dataKey="count" nameKey="city" outerRadius={110} label />
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
