import { useMemo, useState } from "react";
import { api } from "../lib/api";
import RestaurantCard from "../components/RestaurantCard";
import BookingModal from "../components/BookingModal";
import MapView from "../components/MapView";

const locations = {
  Maharashtra: ["Mumbai"],
  Karnataka: ["Bengaluru"],
  Telangana: ["Hyderabad"],
  "West Bengal": ["Kolkata"],
  Delhi: ["New Delhi"],
};

export default function HomePage() {
  const [stateName, setStateName] = useState("Maharashtra");
  const [city, setCity] = useState("Mumbai");
  const [items, setItems] = useState([]);
  const [selected, setSelected] = useState(null);
  const cities = useMemo(() => locations[stateName] || [], [stateName]);

  const useGPS = () => {
    navigator.geolocation.getCurrentPosition(async (pos) => {
      const res = await api.post("/recommend", {
        latitude: pos.coords.latitude,
        longitude: pos.coords.longitude,
        state: stateName,
        city,
      });
      setItems(res.data);
    });
  };

  const search = async () => {
    const res = await api.post("/recommend", { state: stateName, city });
    setItems(res.data);
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-10 text-white">
      <div className="grid lg:grid-cols-2 gap-8 items-center">
        <div>
          <div className="inline-flex rounded-full px-4 py-2 bg-emerald-500/15 text-emerald-300 text-sm border border-emerald-500/20">
            AI restaurant recommendation + backend computer vision analytics
          </div>
          <h1 className="text-5xl font-black mt-5 leading-tight">
            Find the best restaurant with lower wait and smarter recommendations
          </h1>
          <p className="text-slate-300 mt-5 text-lg">
            SmartDine combines distance, crowd count, waiting time, explainable AI, and backend CCTV analysis in one modern interface.
          </p>
          <div className="mt-6 rounded-3xl border border-white/10 bg-white/5 p-5 text-slate-300">
            <div className="text-white font-semibold mb-2">How it works</div>
            Restaurant CCTV or recorded videos are analyzed in the backend using YOLO and OpenCV. Users only see the final crowd level, waiting time, and recommendation results.
          </div>
        </div>

        <div className="rounded-[2rem] border border-white/10 bg-white/5 p-6 shadow-2xl">
          <div className="grid md:grid-cols-2 gap-4">
            <select value={stateName} onChange={(e) => { setStateName(e.target.value); setCity(locations[e.target.value][0]); }} className="rounded-2xl bg-slate-900 border border-white/10 p-3">
              {Object.keys(locations).map((s) => <option key={s}>{s}</option>)}
            </select>
            <select value={city} onChange={(e) => setCity(e.target.value)} className="rounded-2xl bg-slate-900 border border-white/10 p-3">
              {cities.map((c) => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div className="grid md:grid-cols-2 gap-4 mt-4">
            <button onClick={search} className="rounded-2xl bg-emerald-500 text-slate-950 font-semibold py-3">Recommend</button>
            <button onClick={useGPS} className="rounded-2xl bg-white/10 font-semibold py-3">Use GPS</button>
          </div>
          <div className="mt-4 rounded-2xl border border-dashed border-white/15 p-4 text-sm text-slate-300">
            Admins can process CCTV or recorded videos from the Admin page. Regular users do not need to upload any video.
          </div>
        </div>
      </div>

      {items.length > 0 && (
        <>
          <div className="mt-12">
            <h2 className="text-3xl font-bold mb-5">Recommended restaurants</h2>
            <div className="grid xl:grid-cols-2 gap-5">
              {items.map((item) => (
                <RestaurantCard key={item.id} item={item} onBook={setSelected} />
              ))}
            </div>
          </div>
          <div className="mt-10">
            <h2 className="text-3xl font-bold mb-5">Map view</h2>
            <MapView items={items} />
          </div>
        </>
      )}

      <BookingModal restaurant={selected} onClose={() => setSelected(null)} />
    </div>
  );
}
