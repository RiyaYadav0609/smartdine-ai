import { useState } from "react";
import { api } from "../lib/api";

export default function AuthPage() {
  const [mode, setMode] = useState("login");
  const [data, setData] = useState({ name: "", email: "", password: "" });
  const [msg, setMsg] = useState("");

  const submit = async () => {
    try {
      const url = mode === "login" ? "/auth/login" : "/auth/signup";
      const payload = mode === "login"
        ? { email: data.email, password: data.password }
        : data;
      const res = await api.post(url, payload);
      setMsg(res.data.message);
    } catch (e) {
      setMsg(e?.response?.data?.detail || "Request failed");
    }
  };

  return (
    <div className="max-w-md mx-auto p-6">
      <div className="rounded-3xl bg-white/5 border border-white/10 p-6 text-white">
        <h1 className="text-3xl font-bold">{mode === "login" ? "Welcome back" : "Create account"}</h1>
        <p className="text-slate-400 mt-2">Demo auth page for SmartDine AI Pro</p>

        <div className="grid gap-4 mt-6">
          {mode === "signup" && (
            <input className="rounded-2xl bg-white/5 border border-white/10 p-3" placeholder="Name"
              value={data.name} onChange={e => setData({ ...data, name: e.target.value })} />
          )}
          <input className="rounded-2xl bg-white/5 border border-white/10 p-3" placeholder="Email"
            value={data.email} onChange={e => setData({ ...data, email: e.target.value })} />
          <input type="password" className="rounded-2xl bg-white/5 border border-white/10 p-3" placeholder="Password"
            value={data.password} onChange={e => setData({ ...data, password: e.target.value })} />
        </div>

        {msg && <div className="mt-4 text-emerald-300 text-sm">{msg}</div>}

        <button onClick={submit} className="w-full mt-6 rounded-2xl bg-emerald-500 text-slate-950 font-semibold py-3">
          {mode === "login" ? "Login" : "Sign up"}
        </button>
        <button onClick={() => setMode(mode === "login" ? "signup" : "login")} className="w-full mt-3 rounded-2xl bg-white/10 font-semibold py-3 text-white">
          Switch to {mode === "login" ? "signup" : "login"}
        </button>
      </div>
    </div>
  );
}
