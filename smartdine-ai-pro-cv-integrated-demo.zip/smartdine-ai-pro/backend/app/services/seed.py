from sqlalchemy.orm import Session
from app.models.db_models import Restaurant
from app.services.recommender import load_data

def seed_restaurants(db: Session):
    if db.query(Restaurant).count() > 0:
        return
    df = load_data()
    for _, row in df.iterrows():
        db.add(Restaurant(
            id=int(row["id"]),
            name=row["name"],
            state=row["state"],
            city=row["city"],
            latitude=float(row["latitude"]),
            longitude=float(row["longitude"]),
            cuisine=row["cuisine"],
            rating=float(row["rating"]),
        ))
    db.commit()
