from pathlib import Path
import pandas as pd
from geopy.distance import geodesic
from app.services.live_analysis import get_restaurant_analysis

DATA = Path(__file__).resolve().parents[2] / "data" / "restaurants.csv"


def load_data():
    return pd.read_csv(DATA)


def calc_waiting_time(crowd_count: int) -> int:
    return max(5, int(crowd_count * 2.2))


def feature_impact(hour, day_of_week, is_weekend, crowd_count):
    return {
        "hour": round(hour * 0.02, 2),
        "day_of_week": round(day_of_week * 0.03, 2),
        "is_weekend": round(is_weekend * 0.20, 2),
        "crowd_count": round(crowd_count * 0.05, 2),
    }


def recommend(state=None, city=None, latitude=None, longitude=None, hour=19, day_of_week=5, is_weekend=1):
    df = load_data()

    if state:
        df = df[df["state"].str.lower() == state.lower()]
    if city:
        df = df[df["city"].str.lower() == city.lower()]

    if df.empty:
        return []

    if latitude is None or longitude is None:
        latitude = float(df.iloc[0]["latitude"])
        longitude = float(df.iloc[0]["longitude"])

    results = []
    for _, row in df.iterrows():
        restaurant_id = int(row["id"])
        live = get_restaurant_analysis(restaurant_id)

        # fallback to CSV crowd when no analyzed video has been attached yet
        crowd_count = int(row["crowd_count"])
        waiting_time = calc_waiting_time(crowd_count)
        occupied_tables = None
        free_tables = None
        activity_score = None
        analysis_source = "default_dataset"

        if live:
            crowd_count = int(round(live.get("avg_people_count", crowd_count)))
            waiting_time = int(round(live.get("estimated_waiting_time_minutes", waiting_time)))
            occupied_tables = live.get("avg_occupied_tables")
            free_tables = live.get("avg_free_tables")
            activity_score = live.get("overall_dining_activity_score")
            analysis_source = "cv_video_analysis"

        distance = geodesic((latitude, longitude), (row["latitude"], row["longitude"])).km
        smart_score = round((0.55 * waiting_time) + (0.30 * distance) - (0.15 * float(row["rating"] * 10)), 2)

        results.append({
            "id": restaurant_id,
            "name": row["name"],
            "state": row["state"],
            "city": row["city"],
            "cuisine": row["cuisine"],
            "rating": float(row["rating"]),
            "latitude": float(row["latitude"]),
            "longitude": float(row["longitude"]),
            "crowd_count": int(crowd_count),
            "waiting_time": int(waiting_time),
            "distance_km": round(distance, 2),
            "smart_score": smart_score,
            "feature_impact": feature_impact(hour, day_of_week, is_weekend, int(crowd_count)),
            "occupied_tables": occupied_tables,
            "free_tables": free_tables,
            "activity_score": activity_score,
            "analysis_source": analysis_source,
        })

    return sorted(results, key=lambda x: x["smart_score"])[:10]
