from fastapi import APIRouter
from app.schemas import RecommendationRequest
from app.services.recommender import recommend

router = APIRouter(prefix="/recommend", tags=["recommend"])

@router.post("")
def get_recommendations(payload: RecommendationRequest):
    return recommend(
        state=payload.state,
        city=payload.city,
        latitude=payload.latitude,
        longitude=payload.longitude,
        hour=payload.hour,
        day_of_week=payload.day_of_week,
        is_weekend=payload.is_weekend,
    )
