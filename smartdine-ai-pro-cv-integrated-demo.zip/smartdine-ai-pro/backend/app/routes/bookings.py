from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.db_models import Booking, User, Restaurant
from app.schemas import BookingRequest

router = APIRouter(prefix="/bookings", tags=["bookings"])

@router.post("")
def create_booking(payload: BookingRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == payload.user_email).first()
    restaurant = db.query(Restaurant).filter(Restaurant.id == payload.restaurant_id).first()

    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if not restaurant:
        raise HTTPException(status_code=404, detail="Restaurant not found")

    booking = Booking(
        user_id=user.id,
        restaurant_id=restaurant.id,
        guests=payload.guests,
        slot=payload.slot
    )
    db.add(booking)
    db.commit()
    db.refresh(booking)

    return {
        "message": "Booking confirmed",
        "booking_id": booking.id,
        "restaurant": restaurant.name,
        "guests": booking.guests,
        "slot": booking.slot
    }

@router.get("")
def list_bookings(db: Session = Depends(get_db)):
    rows = db.query(Booking, User, Restaurant).join(User, Booking.user_id == User.id).join(Restaurant, Booking.restaurant_id == Restaurant.id).all()
    return [
        {
            "booking_id": booking.id,
            "user": user.name,
            "email": user.email,
            "restaurant": restaurant.name,
            "guests": booking.guests,
            "slot": booking.slot,
            "created_at": booking.created_at.isoformat()
        }
        for booking, user, restaurant in rows
    ]
