from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.db_models import Booking, Restaurant
from app.services.recommender import load_data, recommend

router = APIRouter(prefix="/admin", tags=["admin"])


@router.get("/stats")
def get_stats(db: Session = Depends(get_db)):
    df = load_data()
    total_restaurants = int(db.query(Restaurant).count())
    total_bookings = int(db.query(Booking).count())

    enriched = recommend()
    avg_waiting_time = round(sum(item["waiting_time"] for item in enriched) / len(enriched), 2) if enriched else 0.0
    avg_crowd_count = round(sum(item["crowd_count"] for item in enriched) / len(enriched), 2) if enriched else 0.0
    city_distribution = df.groupby("city").size().to_dict()

    recent = db.query(Booking).order_by(Booking.created_at.desc()).limit(10).all()
    return {
        "total_restaurants": total_restaurants,
        "total_bookings": total_bookings,
        "avg_waiting_time": avg_waiting_time,
        "avg_crowd_count": avg_crowd_count,
        "city_distribution": city_distribution,
        "recent_bookings": [
            {"booking_id": b.id, "restaurant_id": b.restaurant_id, "guests": b.guests, "slot": b.slot}
            for b in recent
        ]
    }
