from pathlib import Path
import shutil

from fastapi import APIRouter, File, Form, UploadFile, HTTPException

from app.services.cv_analyzer import analyze_restaurant_video
from app.services.live_analysis import update_restaurant_analysis
from app.services.recommender import load_data

router = APIRouter(prefix="/video", tags=["video"])
UPLOAD_DIR = Path(__file__).resolve().parents[2] / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)


def estimate_waiting_time(avg_people_count: float, occupied_tables: float, free_tables: float, activity_score: float) -> int:
    wait = 5 + (avg_people_count * 1.8) + (occupied_tables * 3.0) - (free_tables * 2.0)
    if activity_score >= 2.0:
        wait -= 4
    elif activity_score < 0.8:
        wait += 3
    return max(5, int(round(wait)))


@router.get("/restaurants")
def get_restaurants():
    df = load_data()
    return [
        {"id": int(row["id"]), "name": row["name"], "city": row["city"], "state": row["state"]}
        for _, row in df.iterrows()
    ]


@router.post("/upload")
def upload_video(
    restaurant_id: int = Form(...),
    file: UploadFile = File(...),
):
    save_path = UPLOAD_DIR / f"{restaurant_id}_{file.filename}"
    with save_path.open("wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    result = analyze_restaurant_video(str(save_path), frame_skip=5, save_annotated=True)
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["error"])

    estimated_wait = estimate_waiting_time(
        avg_people_count=result["avg_people_count"],
        occupied_tables=result["avg_occupied_tables"],
        free_tables=result["avg_free_tables"],
        activity_score=result["overall_dining_activity_score"],
    )

    payload = {
        "filename": file.filename,
        "avg_people_count": result["avg_people_count"],
        "max_people_count": result["max_people_count"],
        "avg_chair_count": result["avg_chair_count"],
        "avg_table_count": result["avg_table_count"],
        "avg_occupied_tables": result["avg_occupied_tables"],
        "avg_free_tables": result["avg_free_tables"],
        "overall_dining_activity_score": result["overall_dining_activity_score"],
        "overall_dining_activity_label": result["overall_dining_activity_label"],
        "estimated_waiting_time_minutes": estimated_wait,
        "annotated_video_path": result["annotated_video_path"],
        "people_activity": result["people_activity"],
    }
    update_restaurant_analysis(restaurant_id, payload)

    return {
        "message": "Video analyzed and linked to restaurant successfully",
        "restaurant_id": restaurant_id,
        **payload,
    }
